package com.example.ttdautomacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class MacroAccessibilityService : AccessibilityService() {
    data class TapStep(val xPercent: Float, val yPercent: Float, val delayMs: Long)

    /** maxLoops = 0 หมายถึงวนไม่จำกัด (เมื่อเปิดวนซ้ำ) */
    data class Config(
        val repeat: Boolean,
        val maxLoops: Int,
        val maxRetries: Int,
        val startDelaySec: Int
    )

    private val handler = Handler(Looper.getMainLooper())
    private val windowManager by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    private var steps: List<TapStep> = emptyList()
    private var cfg = Config(false, 0, 3, 10)
    private var index = 0
    private var loops = 0
    private var retries = 0
    private var running = false

    private var stopButton: Button? = null
    private var previewView: View? = null

    /** เรียกบน main thread เพื่อแจ้งสถานะไปยังหน้าจอแอป */
    var statusListener: ((String) -> Unit)? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopMacro("ถูกขัดจังหวะโดยระบบ") }

    // ---------- เริ่ม / หยุด ----------

    fun startMacro(raw: String, config: Config) {
        val parsed = parseSteps(raw)
        stopMacro(null)
        steps = parsed
        cfg = config
        index = 0
        loops = 0
        retries = 0
        running = true
        showStopButton()
        countdown(config.startDelaySec)
    }

    fun stopMacro(message: String? = null) {
        running = false
        handler.removeCallbacksAndMessages(null)
        hideStopButton()
        hidePreview()
        if (message != null) report(message)
    }

    private fun report(msg: String) { statusListener?.invoke(msg) }

    private fun countdown(remaining: Int) {
        if (!running) return
        if (remaining <= 0) {
            updateStopButton("■ หยุด")
            report("กำลังทำงาน...")
            scheduleNext()
            return
        }
        updateStopButton("■ หยุด (เริ่มใน $remaining)")
        report("เริ่มใน $remaining วินาที — สลับไปยังเกม")
        handler.postDelayed({ countdown(remaining - 1) }, 1000L)
    }

    // ---------- วงจรการแตะ ----------

    /** รอ delay ของขั้นปัจจุบัน แล้วจึงแตะ */
    private fun scheduleNext() {
        if (!running) return
        if (index >= steps.size) {
            loops++
            if (!cfg.repeat || (cfg.maxLoops > 0 && loops >= cfg.maxLoops)) {
                stopMacro("เสร็จสิ้น ($loops รอบ)")
                return
            }
            index = 0
            report("กำลังทำงาน — เสร็จรอบที่ $loops" +
                if (cfg.maxLoops > 0) " จาก ${cfg.maxLoops}" else "")
        }
        val step = steps[index]
        handler.postDelayed({ tap(step) }, step.delayMs)
    }

    private fun tap(step: TapStep) {
        if (!running) return
        val (w, h) = screenSize()
        val path = Path().apply { moveTo(w * step.xPercent / 100f, h * step.yPercent / 100f) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()

        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (!running) return
                retries = 0
                index++
                scheduleNext()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (running) retryStep()
            }
        }, null)
        if (!accepted) retryStep()
    }

    private fun retryStep() {
        retries++
        if (retries > cfg.maxRetries) {
            stopMacro("หยุด: แตะไม่สำเร็จเกิน ${cfg.maxRetries} ครั้งติดกัน")
            return
        }
        scheduleNext()
    }

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = windowManager.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    // ---------- ปุ่มหยุดลอย ----------

    private fun showStopButton() {
        if (stopButton != null) return
        val button = Button(this).apply {
            text = "■ หยุด"
            setTextColor(Color.WHITE)
            setBackgroundColor(0xDDD32F2F.toInt())
            setOnClickListener { stopMacro("หยุดมาโครแล้ว") }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 160
        }
        try {
            windowManager.addView(button, lp)
            stopButton = button
        } catch (_: Exception) { /* แสดงปุ่มไม่ได้ — มาโครยังทำงานต่อได้ */ }
    }

    private fun updateStopButton(text: String) { stopButton?.text = text }

    private fun hideStopButton() {
        stopButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        stopButton = null
    }

    // ---------- แสดงจุดแตะ (พรีวิว) ----------

    private class PreviewView(context: Context, private val points: List<TapStep>) : View(context) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FF5722.toInt() }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
        }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 40f; textAlign = Paint.Align.CENTER
        }
        override fun onDraw(canvas: Canvas) {
            points.forEachIndexed { i, p ->
                val cx = width * p.xPercent / 100f
                val cy = height * p.yPercent / 100f
                canvas.drawCircle(cx, cy, 44f, fill)
                canvas.drawCircle(cx, cy, 44f, ring)
                canvas.drawText("${i + 1}", cx, cy + 14f, label)
            }
        }
    }

    /** แสดงจุดแตะทั้งหมดบนจอ 5 วินาที เพื่อช่วยปรับพิกัด */
    fun showPreview(raw: String) {
        val parsed = parseSteps(raw)
        hidePreview()
        val view = PreviewView(this, parsed)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        windowManager.addView(view, lp)
        previewView = view
        handler.postDelayed({ hidePreview() }, 5000L)
    }

    private fun hidePreview() {
        previewView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        previewView = null
    }

    override fun onDestroy() {
        stopMacro(null)
        statusListener = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
            private set

        /** รูปแบบ: X,Y,delay ต่อบรรทัด — บรรทัดที่ขึ้นต้นด้วย # ถือเป็นหมายเหตุ */
        fun parseSteps(raw: String): List<TapStep> {
            val parsed = raw.lines().map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .mapIndexed { n, line ->
                    val p = line.split(",").map { it.trim() }
                    require(p.size == 3) { "บรรทัด \"$line\" ต้องเป็น X,Y,delay เช่น 50,80,1000" }
                    val x = p[0].toFloatOrNull()
                    val y = p[1].toFloatOrNull()
                    val delay = p[2].toLongOrNull()
                    require(x != null && y != null && x in 0f..100f && y in 0f..100f &&
                            delay != null && delay >= 250L) {
                        "จุดที่ ${n + 1}: พิกัดต้องอยู่ระหว่าง 0–100 และเวลารออย่างน้อย 250 ms"
                    }
                    TapStep(x, y, delay)
                }
            require(parsed.isNotEmpty()) { "กรุณาใส่รายการแตะอย่างน้อย 1 บรรทัด" }
            return parsed
        }
    }
}
