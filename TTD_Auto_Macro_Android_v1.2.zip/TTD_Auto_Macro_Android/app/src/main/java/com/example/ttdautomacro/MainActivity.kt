package com.example.ttdautomacro

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var sequenceInput: EditText
    private lateinit var repeatBox: CheckBox
    private lateinit var loopsInput: EditText
    private lateinit var retriesInput: EditText
    private lateinit var delayInput: EditText
    private lateinit var presetName: EditText
    private lateinit var status: TextView

    private val prefs by lazy { getSharedPreferences("presets", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        layout.addView(TextView(this).apply {
            text = "TTD AUTO MACRO"
            textSize = 24f
            gravity = Gravity.CENTER
        }, matchWrap())

        layout.addView(TextView(this).apply {
            text = "มาโครแตะหน้าจอทั่วไป — กรอกพิกัดเป็นเปอร์เซ็นต์ของจอ\n" +
                "รูปแบบ: X%,Y%,เวลารอก่อนแตะ(มิลลิวินาที)\n" +
                "ตัวอย่าง: 50,80,1000  (บรรทัดที่ขึ้นต้นด้วย # คือหมายเหตุ)\n" +
                "ระวังอย่าให้จุดแตะทับปุ่ม \"หยุด\" ที่ลอยอยู่มุมขวาบน"
            textSize = 14f
            setPadding(0, 18, 0, 12)
        }, matchWrap())

        sequenceInput = EditText(this).apply {
            hint = "50,80,1000\n25,70,1500"
            setText("50,80,1000\n50,80,1500")
            minLines = 6
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        layout.addView(sequenceInput, matchWrap())

        repeatBox = CheckBox(this).apply {
            text = "วนซ้ำ (ควรเฝ้าดูการทำงาน)"
            isChecked = false
        }
        layout.addView(repeatBox, matchWrap())

        loopsInput = numberRow(layout, "จำนวนรอบสูงสุด (0 = ไม่จำกัด)", "0")
        retriesInput = numberRow(layout, "ลองใหม่เมื่อแตะล้มเหลวได้กี่ครั้ง", "3")
        delayInput = numberRow(layout, "หน่วงก่อนเริ่ม (วินาที)", "10")

        layout.addView(button("เปิดการอนุญาต Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, matchWrap())

        layout.addView(button("แสดงจุดแตะบนจอ (5 วินาที)") {
            val service = requireService() ?: return@button
            try {
                service.showPreview(sequenceInput.text.toString())
                status.text = "แสดงจุดแตะ — สลับไปยังเกมเพื่อดูตำแหน่ง"
            } catch (e: IllegalArgumentException) {
                status.text = e.message ?: "รูปแบบข้อมูลไม่ถูกต้อง"
            }
        }, matchWrap())

        layout.addView(button("เริ่มมาโคร") {
            val service = requireService() ?: return@button
            val config = MacroAccessibilityService.Config(
                repeat = repeatBox.isChecked,
                maxLoops = intOf(loopsInput, 0).coerceAtLeast(0),
                maxRetries = intOf(retriesInput, 3).coerceAtLeast(0),
                startDelaySec = intOf(delayInput, 10).coerceIn(0, 300)
            )
            try {
                service.statusListener = { status.text = it }
                service.startMacro(sequenceInput.text.toString(), config)
            } catch (e: IllegalArgumentException) {
                status.text = e.message ?: "รูปแบบข้อมูลไม่ถูกต้อง"
            }
        }, matchWrap())

        layout.addView(button("หยุด") {
            val service = MacroAccessibilityService.instance
            if (service != null) service.stopMacro("หยุดมาโครแล้ว")
            else status.text = "บริการ Accessibility ยังไม่ทำงาน"
        }, matchWrap())

        // ---- พรีเซ็ต ----
        layout.addView(TextView(this).apply {
            text = "พรีเซ็ต"
            textSize = 16f
            setPadding(0, 20, 0, 4)
        }, matchWrap())
        presetName = EditText(this).apply {
            hint = "ชื่อพรีเซ็ต"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        layout.addView(presetName, matchWrap())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rowLp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        row.addView(button("บันทึก") { savePreset() }, rowLp())
        row.addView(button("โหลด") { pickPreset("โหลดพรีเซ็ต") { loadPreset(it) } }, rowLp())
        row.addView(button("ลบ") { pickPreset("ลบพรีเซ็ต") { deletePreset(it) } }, rowLp())
        layout.addView(row, matchWrap())

        status = TextView(this).apply {
            text = "สถานะ: รอเปิดใช้งาน"
            textSize = 14f
            setPadding(0, 12, 0, 0)
        }
        layout.addView(status, matchWrap())

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    override fun onResume() {
        super.onResume()
        MacroAccessibilityService.instance?.statusListener = { status.text = it }
    }

    override fun onPause() {
        MacroAccessibilityService.instance?.statusListener = null
        super.onPause()
    }

    // ---------- พรีเซ็ต ----------

    private fun savePreset() {
        val name = presetName.text.toString().trim()
        if (name.isEmpty()) { status.text = "กรุณาตั้งชื่อพรีเซ็ตก่อน"; return }
        val json = JSONObject().apply {
            put("seq", sequenceInput.text.toString())
            put("repeat", repeatBox.isChecked)
            put("loops", loopsInput.text.toString())
            put("retries", retriesInput.text.toString())
            put("delay", delayInput.text.toString())
        }
        prefs.edit().putString(name, json.toString()).apply()
        status.text = "บันทึกพรีเซ็ต \"$name\" แล้ว"
    }

    private fun pickPreset(title: String, onPick: (String) -> Unit) {
        val names = prefs.all.keys.sorted()
        if (names.isEmpty()) { status.text = "ยังไม่มีพรีเซ็ตที่บันทึกไว้"; return }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names.toTypedArray()) { _, which -> onPick(names[which]) }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun loadPreset(name: String) {
        val raw = prefs.getString(name, null) ?: return
        try {
            val json = JSONObject(raw)
            sequenceInput.setText(json.getString("seq"))
            repeatBox.isChecked = json.optBoolean("repeat", false)
            loopsInput.setText(json.optString("loops", "0"))
            retriesInput.setText(json.optString("retries", "3"))
            delayInput.setText(json.optString("delay", "10"))
            presetName.setText(name)
            status.text = "โหลดพรีเซ็ต \"$name\" แล้ว"
        } catch (e: Exception) {
            status.text = "โหลดพรีเซ็ตไม่สำเร็จ"
        }
    }

    private fun deletePreset(name: String) {
        prefs.edit().remove(name).apply()
        status.text = "ลบพรีเซ็ต \"$name\" แล้ว"
    }

    // ---------- ตัวช่วย ----------

    private fun requireService(): MacroAccessibilityService? {
        val service = MacroAccessibilityService.instance
        if (service == null) status.text = "กรุณาเปิดบริการ Accessibility ก่อน"
        return service
    }

    private fun intOf(edit: EditText, default: Int) =
        edit.text.toString().trim().toIntOrNull() ?: default

    private fun numberRow(parent: LinearLayout, label: String, default: String): EditText {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply { text = label; textSize = 14f },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val edit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(default)
            minEms = 4
            gravity = Gravity.END
        }
        row.addView(edit, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        parent.addView(row, matchWrap())
        return edit
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
